//
//  Afn.m
//  guoyu_meilin
//
//  Created by admin on 2020/3/31.
//  Copyright © 2020 guoyu_meilin. All rights reserved.
//

#import "Afn.h"

@implementation Afn



+ (BOOL)resetUrl:(NSString *)url{
    
    if (url.length == 0) {
        return NO;
    }else{
        url = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        
        return YES;
        
    }
    
}


+ (void)GetRequst:(NSString *)url params:(NSDictionary *)params resultBlock:(void(^)(id result))block failureBlock:(void(^)( NSError * _Nonnull error))failureblock{
    
    
     if (![Afn resetUrl:url]) {
         return;
     }
     AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
     manager.requestSerializer.timeoutInterval = 30;
     manager.securityPolicy.allowInvalidCertificates = YES;
     manager.securityPolicy.validatesDomainName = NO;

     manager.responseSerializer = [AFJSONResponseSerializer serializerWithReadingOptions:NSUTF8StringEncoding];
     [manager.responseSerializer setAcceptableContentTypes: [NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript",@"text/html",@"text/css", nil]];
     
     [manager GET:url parameters:params progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
         if (responseObject) {
             
             if (block) {
                 
                 block(responseObject);
             }
         }
         
     } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
         
         if (failureblock) {
             failureblock(error);
         }
         
         
         
         
     }];
    
}

+ (void)PostRequst:(NSString *)url params:(NSDictionary *)params resultBlock:(void(^)(id result))block failureBlock:(void(^)( NSError * _Nonnull error))failureblock{
    
    
     if (![Afn resetUrl:url]) {
         return;
     }
     AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
      manager.requestSerializer.timeoutInterval = 30;
      manager.securityPolicy.allowInvalidCertificates = YES;
      manager.securityPolicy.validatesDomainName = NO;
        manager.requestSerializer = [AFJSONRequestSerializer serializer];


      manager.responseSerializer = [AFJSONResponseSerializer serializerWithReadingOptions:NSUTF8StringEncoding];
      
      [manager.requestSerializer setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"contentType"];
      
      [manager.responseSerializer setAcceptableContentTypes: [NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript",@"text/html",@"text/css", @"text/plain",nil]];
      
      
      [manager POST:url parameters:params progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
          if (responseObject) {
              
              if (block) {
                  
                  block(responseObject);
                  
              }
              
          }
          
      } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
          
          if (failureblock) {
              
              failureblock(error);
              
          }
          
      }];
      
    
}



@end
