//
//  Action.m
//  Demo
//
//  Created by slim shady on 2020/4/8.
//  Copyright © 2020 slim shady. All rights reserved.
//

#import "Action.h"

@implementation Action

+(void)home_crete_content:(NSString *)content block:(void(^)(id res))block{
    
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    
    dic[@"id"] = @"123";
    dic[@"content"] = content;
    dic[@"type"] = @0;
    dic[@"state"] = @1;

    [Afn PostRequst:URL params:dic resultBlock:^(id  _Nonnull result) {
        
        
        block(result);
        
        
    } failureBlock:^(NSError * _Nonnull error) {
        
        
        
    }];
    
    
}

+(void)home_list_timestaps:(NSString *)time direction:(NSString *)direction block:(void(^)(id res))block{

    NSDictionary *dic = @{@"id":@"123",
                        @"limit":@"10",
                        @"lastItem":time,
                        @"direction":direction
    };
        
    [Afn GetRequst:URL params:dic resultBlock:^(id  _Nonnull result) {
        
   
        if(block)block(result[@"data"]);
     
    } failureBlock:^(NSError * _Nonnull error) {
        
    }];
    
    
}
@end
