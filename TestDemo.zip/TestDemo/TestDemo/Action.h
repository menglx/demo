//
//  Action.h
//  Demo
//
//  Created by slim shady on 2020/4/8.
//  Copyright © 2020 slim shady. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Action : NSObject

+(void)home_list_timestaps:(NSString *)time direction:(NSString *)direction block:(void(^)(id res))block;


+(void)home_crete_content:(NSString *)content block:(void(^)(id res))block;


@end

NS_ASSUME_NONNULL_END
