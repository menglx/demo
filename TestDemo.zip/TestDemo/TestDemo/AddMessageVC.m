//
//  AddMessageVC.m
//  TestDemo
//
//  Created by slim shady on 2020/4/11.
//  Copyright © 2020 slim shady. All rights reserved.
//

#import "AddMessageVC.h"

@interface AddMessageVC ()

@property (nonatomic, strong) UITextField *texf;

@end

@implementation AddMessageVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"添加新消息";
    
}

- (void)addAction{
    
    if(self.texf.text.length == 0){
        
        
        [SVProgressHUD showErrorWithStatus:@"请输入内容"];
        return;
        
    }
    
    [Action home_crete_content:self.texf.text block:^(id  _Nonnull res) {
        
        [SVProgressHUD showSuccessWithStatus:@"添加成功"];
        [self.navigationController popViewControllerAnimated:YES];

    }];
       
   
    
}

@end
