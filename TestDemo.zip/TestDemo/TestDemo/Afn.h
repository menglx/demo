//
//  Afn.h
//  guoyu_meilin
//
//  Created by admin on 2020/3/31.
//  Copyright © 2020 guoyu_meilin. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Afn : NSObject

+ (void)GetRequst:(NSString *)url params:(NSDictionary *)params resultBlock:(void(^)(id result))block failureBlock:(void(^)( NSError * _Nonnull error))failureblock;

+ (void)PostRequst:(NSString *)url params:(NSDictionary *)params resultBlock:(void(^)(id result))block failureBlock:(void(^)( NSError * _Nonnull error))failureblock;


@end

NS_ASSUME_NONNULL_END
