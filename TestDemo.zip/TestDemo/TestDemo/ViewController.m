//
//  ViewController.m
//  TestDemo
//
//  Created by slim shady on 2020/4/11.
//  Copyright © 2020 slim shady. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (strong, nonatomic) UITableView *tableView;

@property (nonatomic, strong) NSString *creationTime;


@property (nonatomic, strong) NSMutableArray *categoryData;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.categoryData = [NSMutableArray array];

    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.tableView registerClass:TableViewCell.class forCellReuseIdentifier:@"TableViewCell"];

    
    
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"添加消息" style:UIBarButtonItemStyleDone target:self action:@selector(addAction)];
    
    
    
    [self loadData];
    
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadData)];
    
    self.tableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreListData)];
    
}


- (void)loadMoreListData{
    
    
    [Action home_list_timestaps:self.creationTime direction:@"0" block:^(id  _Nonnull res) {


        NSMutableIndexSet *index = [NSMutableIndexSet indexSetWithIndexesInRange:NSMakeRange(0, [res[@"items"] count])];
        
        [self.categoryData  insertObjects:res[@"items"] atIndexes:index];
        

        [self.tableView.mj_footer endRefreshing];
        [self.tableView reloadData];


    }];

    
}


- (void)loadData{
    
    [Action home_list_timestaps:@"" direction:@"1" block:^(id  _Nonnull res) {

     
        
        self.categoryData = [[[res[@"items"] reverseObjectEnumerator] allObjects] mutableCopy];
        
        self.creationTime = res[@"lastItem"][@"creationTime"];

        [self.tableView.mj_header endRefreshing];
        [self.tableView reloadData];

    }];


}










- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.categoryData.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    TableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"TableViewCell" forIndexPath:indexPath];
    [cell setdic:self.categoryData[indexPath.row]];
    return cell;
}


- (void)addAction{
    [self.navigationController pushViewController:[AddMessageVC new] animated:YES];
}
@end
