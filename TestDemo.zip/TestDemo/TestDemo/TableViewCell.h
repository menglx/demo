//
//  TableViewCell.h
//  TestDemo
//
//  Created by slim shady on 2020/4/11.
//  Copyright © 2020 slim shady. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TableViewCell : FlexBaseTableCell

@property (strong, nonatomic) UILabel *name;

- (void)setdic:(NSMutableDictionary *)dic;

@end

NS_ASSUME_NONNULL_END
