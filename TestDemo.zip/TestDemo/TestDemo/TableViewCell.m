//
//  TableViewCell.m
//  TestDemo
//
//  Created by slim shady on 2020/4/11.
//  Copyright © 2020 slim shady. All rights reserved.
//

#import "TableViewCell.h"

@interface TableViewCell()


@end

@implementation TableViewCell

- (void)setdic:(NSMutableDictionary *)dic{
    
    self.name.text = [NSString stringWithFormat:@"%@",dic[@"content"]];
    
}

@end
