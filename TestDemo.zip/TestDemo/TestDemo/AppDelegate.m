//
//  AppDelegate.m
//  TestDemo
//
//  Created by slim shady on 2020/4/11.
//  Copyright © 2020 slim shady. All rights reserved.
//

#import "AppDelegate.h"


@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    
    FlexRestorePreviewSetting();
    
    
    UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:[NSClassFromString(@"ViewController") new]];
    
    self.window.rootViewController = nav;
    self.window.backgroundColor = UIColor.redColor;
    [self.window makeKeyAndVisible];
    return YES;
}

@end
